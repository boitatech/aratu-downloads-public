<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="css/style.css">
</head>

<body>


<b>
	<h1> Ambiente em construção </h1>
	<img src="images/warning.png">
</b>


<! -- Vsm, consulte os logs por func.php?action=logs&id=1!! --> 
  
<?php

$url = $_GET["parametrosupersecretors"];

if(isset($url)) {
   echo "<br>";
   echo file_get_contents("http://".$url);
}

?>

</body>
</html>
