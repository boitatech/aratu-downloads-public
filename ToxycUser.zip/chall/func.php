<html>
	<head>
		<link rel="stylesheet" href="css/style.css">
	</head>

</body>

<?php

$action = $_GET["action"];
$id = $_GET["id"];
$server = $_SERVER['SERVER_ADDR'];
$client = $_SERVER['REMOTE_ADDR'];

function logs($lo) {
  if($lo == 1) {
  echo "<div>[Dev] Sidhawks: Estou adicionado novas funções, e deixando o codigo com molho necessário</div>";
  }
  if($lo == 20) {
  echo "<div>[Dev] Vsm: krai sidhawks KKKKK, o codigo ta cheio de vulni krai KKKKKK</div>";
  }
  if($lo == 100) {
  echo "<div>[Dev] Vsm: sidhawks, nao esquece de tirar o parametro url do index. Caso precise usar: index.php?parametrosupersecretors=google.com</div>";
  } else {
  echo "<h1>Esse log nao existe!</h1>"; 
  }
}

function exist($action, $id) {
  if (isset($action) || isset($id)) {
    $action("$id");
  }
}


if ($action  == "logs") { 
  exist($action, $id);
  } elseif ($client == $server) {
  exist($action, $id);
  } else {
  echo "<h1>Apenas pra acesso local!</h1>";
}

?>

</body>

</html>
